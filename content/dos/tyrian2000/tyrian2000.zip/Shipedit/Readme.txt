
This is included separately for your convenience in seeing how ShipEdit works and playing 
around with it.

It's a cheat program which hacks the game a little bit, but it's pretty safe since it doesn't
do much of anything except write a shape table file containing a little bit of extra
information.

If you want to run this program it needs to be copied to the main Tyrian directory as it needs
to see the files there.

Other than that, have fun playing with it. :)