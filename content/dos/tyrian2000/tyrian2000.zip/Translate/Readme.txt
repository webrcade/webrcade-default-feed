
These are the main files that would need to be translated.  I'll update this directory as I
discover anything I may not have otherwise realized needed translation and move text out
from the program files or other difficult to translate files.  As of this writing, about
95+% of the game text is located in these files.

This does not include the graphical files used in the game which contain various logos.