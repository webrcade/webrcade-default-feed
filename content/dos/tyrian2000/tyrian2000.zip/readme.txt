
TYRIAN 2000 (TM)
Version 3.0

Published by

XSIV GAMES

Game Copyright (C) 1999 Eclipse
Copyright (C) 1999 Stealth Productions, Inc. (SM)
All Rights Reserved

RELEASE NOTES: v3.0
August 31, 1998

PLEASE READ THIS CAREFULLY.

If you have any questions or comments then send e-mail to
<support@stealthprd.com>

=============================================

Operating Notes:

1. Playing CD music on slower CD-ROM's will cause a slight pause during the game when a
   music piece replays during a level.

2. Playing of the video sequences on slower CD-ROM's during SETUP or at the end of the
   game may not produce a clean playback.

3. The music is CD Audio Stereo. An audio CD with the soundtrack is also available.

4. Please read the manual as it contains important information and hints.

5. SUPPORTED MULTIPLAYER MODES: Two players on the same PC. 

6. PD drives may not be able to play the CD music. Please contact us if you have this
    problem.

7. We have included a GOODIES folder on the CD that contains setup programs for DirectX 6.0
    ENGLISH language version and Indeo Video Player 5.0.

8. If you want to uninstall Tyrian 2000(TM) from your hard drive then we strongly recommend
    using the uninstall option from the start/programs/stealth/Tyrian 2000 menu.

===============================

Please send all written inquiries to:

XSIV GAMES
Attn.: Customer Service
P.O. Box 4010
Beverly Hills, CA 90213-4010

Internet Addresses:

WWW.XSIVGAMES.COM

Customer Service: support@stealthprd.com

Sales: sales@stealthprd.com

Site Information: webmaster@stealthprd.com

General Questions: info@stealthprd.com

=======================================

GAME COPYRIGHT (C) 1999, ECLIPSE 
COPYRIGHT (C) 1999, STEALTH PRODUCTIONS, INC. (SM) TYRIAN 2000 AND THE TYRIAN 2000 LOGO,
XSIV GAMES AND THE XSIV GAMES LOGO ARE TRADEMARKS AND COPYRIGHTS OF STEALTH PRODUCTIONS,
INC. ALL RIGHTS RESERVED.