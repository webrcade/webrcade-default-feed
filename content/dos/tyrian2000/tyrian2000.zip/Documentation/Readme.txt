
In this directory:


== Helpme 

An application from Epic that simply lists information about the game Tyrian,
including at least part of the manual.


== Manual.doc

Original copy of the game manual.


== Tyrcheat.doc

A file by me, written in Word for Windows format, that contains most of the cheats and hints
present within the game.