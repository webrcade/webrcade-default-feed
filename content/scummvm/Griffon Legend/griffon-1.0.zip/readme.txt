The Griffon Legend - by - Syn9 - http://syn9.thingie.net - syn9@rpgdx.net

programming/graphics by syn9
music/sound effects by David Turner
beta testing and gameplay design help provided by:
  Deleter, Cha0s, Aether Fox, and Kiz


here are the controls:

ctrl - use item/cast spell
space - attack
esc - main menu

alt-enter - fullscreen/window


during gameplay, you'll can see up to 3 bars below your character, the top is health, the next is attack strength (let it charge to hit harder) and spell strangth (same as attack). when you learn new spells you will see their icons in the bottom right corner with a meter below them to show them charging.  when the meter turns orange they are ready for use.


-------


you can edit the config.ini to change the display settings, if you cant get to the options menu

if you are having slowdown problems, or video card issues, try changing either of these lines in the config.ini from YES to NO.
HWACCEL:YES
HWSURFACE:YES


at the time of release i have been having a problem with the music, it gets distorted then goes back to normal, and as of yet i havent been able to fix it, so im releasing the game w/ the bug.  if i am able to fix it, i'll post a link on my site

special thanks to pete for writing the article on the game, that was awsome!  as well as all the beta testers for putting so much time into making the game fun.  and everyone who has kept up with the game waiting for it to be released, i am very honoured that so many people were looking forward to this game.

i really hope everyone who plays this game enjoys it.  ive tried to get as much criticism as i can to make sure it is wellrounded and incorporates all the necessities for a game of this style.  also any comments or criticism is always welcome at the syn9.thingie.net forums!

thank you for taking time to read this, and enjoy the game!